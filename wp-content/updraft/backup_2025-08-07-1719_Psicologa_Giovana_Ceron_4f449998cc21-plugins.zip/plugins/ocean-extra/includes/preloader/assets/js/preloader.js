window.addEventListener('load',  async function () {

   document.body.classList.remove('ocean-preloader--active');

   const element = document.getElementById('ocean-preloader');
    element.remove();
});