<?php
/**
 * OceanWP Customizer: Common functions
 *
 * @package OceanWP WordPress theme
 */

// if ( ! defined( 'ABSPATH' ) ) {
// 	exit;
// }
